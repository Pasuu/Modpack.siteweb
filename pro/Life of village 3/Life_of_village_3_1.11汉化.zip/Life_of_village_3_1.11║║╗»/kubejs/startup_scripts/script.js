// priority: 0

console.info('Script for creating new items is starting...')

onEvent('item.registry', event => {
	// Register new items here
	// event.create('example_item').displayName('Example Item')

event.create('copper_coin').displayName('铜币').tooltip('通过任务获取')
event.create('iron_coin').displayName('铁币').tooltip('通过任务获取')
event.create('gold_coin').displayName('金币').tooltip('通过任务获取')
event.create('diamond_coin').displayName('钻石硬币').tooltip('通过任务获取')
event.create('netherite_coin').displayName('下界合金币').tooltip('通过任务获取')
event.create('monster_coin').displayName('怪物硬币')
event.create('nether_coin').displayName('下界硬币').tooltip('通过下界章节任务获取')

event.create('diamond_nugget').displayName('钻石粒')
event.create('emerald_nugget').displayName('绿宝石粒')


event.create('coin_01').displayName('硬币')
event.create('coin_02').displayName('一对硬币')
event.create('coin_03').displayName('一小叠硬币')
event.create('coin_04').displayName('一小堆硬币')
event.create('coin_05').displayName('很多硬币')

event.create('medal').displayName('奖章').glow(true)
event.create('heart').displayName('心')

event.create('fox').displayName('ShadowFoxy Patreon Supporter Icon')
event.create('kruscle').displayName('Kruscle Patreon Supporter Icon')
})

onEvent('block.registry', event => {
	// Register new blocks here
	// event.create('example_block').material('wood').hardness(1.0).displayName('Example Block')
})