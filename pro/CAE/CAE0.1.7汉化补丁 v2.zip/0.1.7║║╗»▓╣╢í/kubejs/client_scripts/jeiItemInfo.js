onEvent('jei.information', event => {
    event.add('minecraft:soul_sand', ['灵魂汲取', '由于奥术的消散，仅会自然生成失魂沙，如果要重新注入灵魂，需要让一个游魂站在它的上方。'])
    event.add('forbidden_arcanus:soulless_sand', ['灵魂汲取', '由于奥术的消散，仅会自然生成失魂沙，如果要重新注入灵魂，需要让一个游魂站在它的上方。'])
    event.add(/sophisticatedbackpacks:.*backpack/, "背包升级：先将背包放下（shift+右键），然后用提到的升级材料右键即可升级")
})